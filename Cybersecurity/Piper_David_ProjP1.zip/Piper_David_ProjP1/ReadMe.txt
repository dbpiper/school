This program encrypts and decrypts files using the cipher given in the description. 
It is written in C# and has a Windows Form GUI. 

It has an Input box next to which is a Browse button. Selecting this allows the user to select a file for input.

It has an Output box next to which is a Browse button. Selecting this allows the user
to select a file to save for output.

There is a Decrypt checkbox. When this is checked the program will decrypt the input and store this in output file. Otherwise, it will encrypt the input and store the ciphertext in the output file.

Selecting the Run button actually starts the process.
